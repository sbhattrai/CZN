CREATE TABLE `superhero` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `superName` varchar(255) DEFAULT NULL,
  `realName` varchar(255) DEFAULT NULL,
  `powers` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `height` double DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `sex` char(1) DEFAULT NULL,
  `superTeamID` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `superTeamID` (`superTeamID`),
  CONSTRAINT `superhero_ibfk_1` FOREIGN KEY (`superTeamID`) REFERENCES `superteam` (`superTeamID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
