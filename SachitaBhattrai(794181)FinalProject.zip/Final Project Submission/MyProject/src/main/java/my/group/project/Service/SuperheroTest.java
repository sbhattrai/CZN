package my.group.project.Service;

public class SuperheroTest {
}
