package my.group.project.controller;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import my.group.project.Service.SuperHeroService;
import my.group.project.dto.SuperHero;

@Controller
public class HomeController {
	
	
	
	private SuperHeroService service;
	@Inject
	public void setService(SuperHeroService service) {
		this.service = service;
	}

	@RequestMapping(value ="/Review")
	public ModelAndView Review(@RequestParam(required=false, defaultValue="World") String name1) {
		ModelAndView ret = new ModelAndView("Review");
		// Adds an object to be used in home.jsp
		ret.addObject("name1", service.getSuperTeams());
		return ret;
	}
	
	
	@RequestMapping
	public ModelAndView hello(@RequestParam(required=false, defaultValue="World") String name) {
		ModelAndView ret = new ModelAndView("hello");
		// Adds an object to be used in home.jsp
		ret.addObject("name", name);
		return ret;
	}
	
	
	@RequestMapping(value="/hi")
	public ModelAndView hi(@RequestParam(required=false, defaultValue="World") String name) {
		ModelAndView ret = new ModelAndView("hi");
		// Adds an object to be used in home.jsp
		ret.addObject("name", service.getAllSuperHeroes());
		return ret;
	}
	
	
	
    @RequestMapping(value="input", method = RequestMethod.GET)
	public ModelAndView getSuperheroId() {
    	ModelAndView model = new ModelAndView("input");
	return model;
		
	}
	
   
	@RequestMapping(value="result", method = RequestMethod.POST)
	public ModelAndView result(@RequestParam("inputid") int id ){
		ModelAndView model = new ModelAndView("result");
		model.addObject("name", service.getSuperHeroById(id));
	
		return model ;
		
	}
	
	@RequestMapping(value="process", method = RequestMethod.GET)
	public ModelAndView getSuperteamId() {
    	ModelAndView model = new ModelAndView("process");
	return model;
		
	}
	
	@RequestMapping(value="outcome", method = RequestMethod.POST)
	public ModelAndView outcome(@RequestParam("id") int id ){
		ModelAndView model = new ModelAndView("outcome");
		model.addObject("name", service.getSuperTeamById(id));
	
		return model ;
		
	
	}
	
	
	@RequestMapping(value ="/AboutSuperHero")
	public ModelAndView AboutSuperHero(@RequestParam(required=false, defaultValue="World") String name) {
		ModelAndView ret = new ModelAndView("AboutSuperHero");
		// Adds an object to be used in home.jsp
		ret.addObject("name", name);
		return ret;
	}
}




