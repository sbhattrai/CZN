package myPackage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class myTestCase2 {
	
public static void main(String[] args) {
	System.setProperty("webdriver.chrome.driver","C:\\Development_Avecto/chromedriver_win32/chromedriver.exe");
	 var options = new ChromeOptions();
	 options.addArguments("--no-sandbox");
	 WebDriver driver = new ChromeDriver(options);
		
		
       String baseUrl = "http://localhost:8080/project/hello";
       
       String expectedTitle = "My Website";
       String actualTitle = "project";
       
       

       // launch Fire fox and direct it to the Base URL
       driver.get(baseUrl);

       // get the actual value of the title
       actualTitle = driver.getTitle();

       /*
        * compare the actual title of the page with the expected one and print
        * the result as "Passed" or "Failed"
        */
       if (actualTitle.contentEquals(expectedTitle)){
           System.out.println("Test Passed!");
       } else {
           System.out.println("Test Failed");
       }
      
      // driver.get("http://localhost:8080/project/hello");
       
       
       WebElement linkByText3 = driver.findElement(By.linkText("Find superhero by ID"));	        
       linkByText3.click();
       
       System.out.println(" CLick Test Failed!");
       
 
       
       WebElement textBox = driver.findElement(By.id("input"));
       textBox.sendKeys("4");
       
       WebElement submiButton = driver.findElement(By.id("submitButtonId"));
       submiButton .click();			
       System.out.println("superhero retrived success");	
       
 	        
      //driver.close();
       
       	
       }

       
       
     
}

	