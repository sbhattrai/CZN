package myPackage;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;

//import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;






public class JunitTest1 {
	//private static String baseUrl = "http://localhost:8080/project/hello";
	static WebDriver driver;
	
	
	 


	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver","C:\\\\Development_Avecto/chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(500,TimeUnit.MILLISECONDS);
	}

	

//	@BeforeEach
//	void setUp() throws Exception {
//		driver.get(baseUrl);
//	}

//	@AfterEach
//	void tearDown() throws Exception {
//	}	
		
	@Test
	public void test1() {
		
	    //   WebElement textBox = driver.findElement(By.id("input"));
//	       textBox.sendKeys("4");
		driver.manage().timeouts().implicitlyWait(500,TimeUnit.MILLISECONDS);
		 driver.get("http://localhost:8080/project/hello");
		 driver.findElement(By.linkText("Find superhero by ID")).click();

	      driver.findElement(By.id("input")).sendKeys("4");
        // WebElement superheroSearch = driver.findElement(By.id("submitButtonId"));
         //superheroSearch.click();			
   // System.out.println("superhero retrived success");
	}
	
	
	
	
	@Test
	public void test2() {
		
	    //   WebElement textBox = driver.findElement(By.id("input"));
//	       textBox.sendKeys("0");
		driver.manage().timeouts().implicitlyWait(500,TimeUnit.MILLISECONDS);
		 driver.get("http://localhost:8080/project/hello");
		 driver.findElement(By.linkText("Find superhero by ID")).click();

	      driver.findElement(By.id("input")).sendKeys("0");
//	       WebElement superheroSearch = driver.findElement(By.id("submitButtonId"));
//	      superheroSearch.click();			
//	      System.out.println("superhero retrived success");
	}

	
	@Test
	public void test3() {
	
		driver.manage().timeouts().implicitlyWait(500,TimeUnit.MILLISECONDS);
		driver.get("http://localhost:8080/project/process");
	    WebElement superTeambyCorrectID = driver.findElement(By.id("id"));
        superTeambyCorrectID.sendKeys("1");
	    driver.findElement(By.id("submitButtonId")).click();
	    driver.get("http://localhost:8080/project/outcome");
	    List<WebElement> name = driver.findElements(By.id("teamName"));
	    for(WebElement x:name) {
	    	if(x.getText().equals("JusticeLeague")) {
	    		assertEquals("JusticeLeague",x.getText());
	    	}
	    }
	    
	    
	    
	    
//	       WebElement superheroSearch = driver.findElement(By.id("submitButtonId"));
//	      superheroSearch.click();			
//	      System.out.println("superteam retrived success");
	}

	@Test
	public void test4() {
		
	    //   WebElement textBox = driver.findElement(By.id("input"));
//	       textBox.sendKeys("4");
		driver.manage().timeouts().implicitlyWait(500,TimeUnit.MILLISECONDS);
		 driver.get("http://localhost:8080/project/hello");
		 driver.findElement(By.linkText("Find superteam by ID")).click();

	      driver.findElement(By.id("submitButtonId")).sendKeys("4");
//	       WebElement superheroSearch = driver.findElement(By.id("submitButtonId"));
//	      superheroSearch.click();			
//	      System.out.println("superteam retrived success");
	}
	@Test
	public void test5() {
		
	    //   WebElement textBox = driver.findElement(By.id("input"));
//	       textBox.sendKeys("0");
		driver.manage().timeouts().implicitlyWait(500,TimeUnit.MILLISECONDS);
		 driver.get("http://localhost:8080/project/hello");
		 driver.findElement(By.linkText("Find superteam by ID")).click();

	      driver.findElement(By.id("submitButtonId")).sendKeys("0");
//	       WebElement superheroSearch = driver.findElement(By.id("submitButtonId"));
//	      superheroSearch.click();			
//	      System.out.println("superteam retrived success");
	}
	
	
	
	@Test
	public void test6() {
	
		driver.manage().timeouts().implicitlyWait(500,TimeUnit.MILLISECONDS);
		driver.get("http://localhost:8080/project/input");
	    WebElement superHerobyCorrectID = driver.findElement(By.id("input"));
        superHerobyCorrectID.sendKeys("1");
	    driver.findElement(By.id("submitButtonId")).click();
	    //driver.get("http://localhost:8080/project/result");
	     WebElement name = driver.findElement(By.id("heroName"));
	     assertEquals("SpiderMan",name.getText());
	    }
	    			
	@Test
	public void test7() {
		driver.get("http://localhost:8080/project/hello");
	    String URL = driver.getCurrentUrl();
	    Assert.assertTrue(URL.contains("http://localhost:8080/project/hello"));
	    System.out.println(URL);
	}
	
	@AfterAll
	static void tearDownAfterClass() throws Exception {
    driver.close();
		System.out.println("End of test");
	}
	
}







